'''How to create variables in Python'''

# Integer variable
age = 25
print("Age:", age)  

# Float variable
height = 5.9
print("Height:", height)  

# String variable
name = "Divyaraj"
print("Name:", name)  

# Boolean variable
is_student = True
print("Is a student:", is_student)  

# List variable
favorite_colors = ["blue", "green", "red"]
print("Favorite colors:", favorite_colors)  

# Tuple variable
coordinates = (10.0, 20.0)
print("Coordinates:", coordinates)  

# Dictionary variable
person_info = {
    "name": name,
    "age": age,
    "height": height,
    "is_student": is_student
}
print("Person info:", person_info)  

# Set variable
unique_numbers = {1, 2, 3, 4, 5}
print("Unique numbers:", unique_numbers)  
