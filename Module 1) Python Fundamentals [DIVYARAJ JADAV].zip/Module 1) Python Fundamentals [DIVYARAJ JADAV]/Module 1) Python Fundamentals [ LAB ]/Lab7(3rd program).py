'''Write a Python program to print a string using triple quotes.'''

# Print the string using triple quotes
print("""Hello, world!""")
