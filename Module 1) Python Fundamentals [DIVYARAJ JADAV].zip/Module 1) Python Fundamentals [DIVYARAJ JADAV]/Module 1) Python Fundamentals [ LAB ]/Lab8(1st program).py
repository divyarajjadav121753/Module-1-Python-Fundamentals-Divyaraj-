'''Write a Python program to skip 'banana' in a list using the continue
statement. List1 = ['apple', 'banana', 'mango']'''

# List of fruits
List1 = ['apple', 'banana', 'mango']

# Loop through the list and skip 'banana' using the continue statement
for fruit in List1:
    if fruit == 'banana':
        continue
    print(fruit)
