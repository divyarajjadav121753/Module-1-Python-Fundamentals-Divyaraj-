''' Write a Python program to print every alternate character from the string starting from index 1.'''

# Define the string
my_string = "Hello, world!"

# Print every alternate character starting from index 1
alternate_chars = my_string[1::2]

# Print the result
print(f"Every alternate character from the string starting from index 1 is: '{alternate_chars}'")
