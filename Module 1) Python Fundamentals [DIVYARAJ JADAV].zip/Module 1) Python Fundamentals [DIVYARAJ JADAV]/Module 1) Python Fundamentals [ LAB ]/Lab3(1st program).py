'''Write a Python program to demonstrate the creation of variables and different data types.'''

# Variable creation and different data types

# String data type
name = "Divyaraj"
print("Name:", name)

# Integer data type
age = 30
print("Age:", age)

# Float data type
height = 5.5  # in feet
print("Height:", height)

# Boolean data type
is_student = True
print("Is a student:", is_student)

# List data type
favorite_colors = ["blue", "green", "red"]
print("Favorite colors:", favorite_colors)

# Tuple data type
coordinates = (10.0, 20.0)
print("Coordinates:", coordinates)

# Dictionary data type
person_info = {
    "name": name,
    "age": age,
    "height": height,
    "is_student": is_student
}
print("Person info:", person_info)

# Set data type
unique_numbers = {1, 2, 3, 4, 5}
print("Unique numbers:", unique_numbers)
