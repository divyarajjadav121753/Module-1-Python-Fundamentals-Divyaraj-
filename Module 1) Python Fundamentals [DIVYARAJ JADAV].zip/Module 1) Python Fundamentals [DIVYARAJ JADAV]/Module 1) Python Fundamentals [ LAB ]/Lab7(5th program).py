''' Write a Python program to access the string from the second position onwards using slicing'''

# Define the string
my_string = "Hello, world!"

# Access the string from the second position onwards using slicing
substring = my_string[1:]

# Print the substring
print(f"The string from the second position onwards is: '{substring}'")
