'''Write a Python program that filters out even numbers using the filter() function.'''

# Function to check if a number is odd
def is_odd(num):
    return num % 2 != 0

# Define a list of numbers
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Use the filter() function to filter out even numbers
odd_numbers = list(filter(is_odd, numbers))

# Print the filtered list of odd numbers
print(f"The odd numbers are: {odd_numbers}")
