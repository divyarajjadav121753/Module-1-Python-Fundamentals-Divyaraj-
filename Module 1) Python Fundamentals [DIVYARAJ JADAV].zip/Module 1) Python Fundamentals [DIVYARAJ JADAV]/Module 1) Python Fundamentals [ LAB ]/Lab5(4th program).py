'''Print this pattern using nested for loop:
markdown
Copy code
*
**
***
****
*****'''

# Function to print the pattern
def print_pattern(rows):
    for i in range(1, rows + 1):
        for j in range(i):
            print("*", end="")
        print()

# Example usage
rows = 5
print_pattern(rows)
