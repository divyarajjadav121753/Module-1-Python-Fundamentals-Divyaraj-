'''How to check the type of a variable dynamically using type().'''

# Create variables of different types
name = "Divyaraj"
age = 25
height = 5.9
is_student = True
favorite_colors = ["blue", "green", "red"]
coordinates = (10.0, 20.0)
person_info = {
    "name": name,
    "age": age,
    "height": height,
    "is_student": is_student
}
unique_numbers = {1, 2, 3, 4, 5}

# Check the type of each variable
print(type(name)) 
print(type(age))  
print(type(height))  
print(type(is_student))  
print(type(favorite_colors))  
print(type(coordinates))  
print(type(person_info))  
print(type(unique_numbers))  
