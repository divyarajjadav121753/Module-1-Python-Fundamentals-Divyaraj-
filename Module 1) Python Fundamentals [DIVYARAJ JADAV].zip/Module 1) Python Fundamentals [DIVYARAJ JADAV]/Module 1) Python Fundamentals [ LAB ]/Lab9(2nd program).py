'''Write a Python program that manipulates and prints strings using various string methods.'''

# Define a string
my_string = "Hello, World!"

# Convert the string to uppercase
uppercase_string = my_string.upper()
print(f"Uppercase: {uppercase_string}")

# Convert the string to lowercase
lowercase_string = my_string.lower()
print(f"Lowercase: {lowercase_string}")

# Capitalize the first character of the string
capitalized_string = my_string.capitalize()
print(f"Capitalized: {capitalized_string}")

# Replace a substring in the string
replaced_string = my_string.replace("World", "Python")
print(f"Replaced: {replaced_string}")

# Find the index of a substring in the string
index_of_world = my_string.find("World")
print(f"Index of 'World': {index_of_world}")

# Split the string into a list of substrings
split_string = my_string.split(", ")
print(f"Split: {split_string}")

# Strip whitespace from the beginning and end of the string
stripped_string = my_string.strip()
print(f"Stripped: {stripped_string}")

# Check if the string starts with a specific substring
starts_with_hello = my_string.startswith("Hello")
print(f"Starts with 'Hello': {starts_with_hello}")

# Check if the string ends with a specific substring
ends_with_exclamation = my_string.endswith("!")
print(f"Ends with '!': {ends_with_exclamation}")
