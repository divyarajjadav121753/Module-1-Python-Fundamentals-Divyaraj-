'''Write a Python program to access the first character of a string using index value'''

# Define the string
my_string = "Hello, world!"

# Access the first character using index value
first_character = my_string[0]

# Print the first character
print(f"The first character of the string is: '{first_character}'")
