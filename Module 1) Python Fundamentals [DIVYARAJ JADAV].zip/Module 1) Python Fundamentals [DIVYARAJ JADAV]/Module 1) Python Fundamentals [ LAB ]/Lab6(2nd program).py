'''Write a Python program that uses a custom iterator to iterate over a list of integers.'''

# Custom iterator class
class CustomIterator:
    def __init__(self, data):
        self.data = data
        self.index = 0
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.index < len(self.data):
            result = self.data[self.index]
            self.index += 1
            return result
        else:
            raise StopIteration

# Example usage
list_of_integers = [10, 20, 30, 40, 50]
iterator = CustomIterator(list_of_integers)

for value in iterator:
    print(value)
