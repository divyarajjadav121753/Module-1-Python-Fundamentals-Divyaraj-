'''Write a Python program to demonstrate string slicing.'''

# Define a string
my_string = "Hello, world!"

# Access a substring from the beginning to a specific position
substring1 = my_string[:5]
print(f"Substring from the beginning to index 4: '{substring1}'")

# Access a substring from a specific position to the end
substring2 = my_string[7:]
print(f"Substring from index 7 to the end: '{substring2}'")

# Access a substring between specific index values
substring3 = my_string[1:5]
print(f"Substring between index 1 and 4: '{substring3}'")

# Access a substring with a step (every 2nd character)
substring4 = my_string[::2]
print(f"Every 2nd character in the string: '{substring4}'")

# Access the string in reverse order
reversed_string = my_string[::-1]
print(f"The string in reverse order: '{reversed_string}'")
