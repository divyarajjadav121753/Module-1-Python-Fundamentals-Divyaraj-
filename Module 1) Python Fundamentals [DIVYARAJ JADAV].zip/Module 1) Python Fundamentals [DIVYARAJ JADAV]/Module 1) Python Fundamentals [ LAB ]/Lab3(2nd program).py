'''How does the Python code structure work?'''

# Import necessary modules
import math

# Define a function
def calculate_circle_area(radius):
    """Calculate the area of a circle given its radius."""
    return math.pi * (radius ** 2)

# Main function
def main():
    # Prompt user for radius
    radius = float(input("Enter the radius of the circle: "))
    
    # Calculate area
    area = calculate_circle_area(radius)
    
    # Print the result
    print(f"The area of the circle with radius {radius} is {area:.2f}")

# Call the main function if the script is executed directly
if __name__ == "__main__":
    main()
