'''Write a Python program that demonstrates the correct use of indentation, comments, and
variables following PEP 8 guidelines.'''

# Import necessary modules
import datetime

# Define the main function
def main():
    """Main function to demonstrate PEP 8 guidelines."""
    
    # Define variables
    name = "Divyaraj"
    age = 30

    # Print a welcome message
    print(f"Hello, {name}!")
    
    # Calculate the birth year
    current_year = datetime.datetime.now().year
    birth_year = current_year - age

    # Print the birth year
    print(f"You were born in {birth_year}.")

# Call the main function
if __name__ == "__main__":
    main()
