'''Write a Python program to access a string up to the fifth character'''

# Define the string
my_string = "Hello, world!"

# Access the string up to the fifth character using slicing
substring = my_string[:5]

# Print the substring
print(f"The string up to the fifth character is: '{substring}'")
