'''Set up Python on your local machine and write a program to display your name.'''

print("Divyaraj Jadav")
print("Sanket Chauhan")

