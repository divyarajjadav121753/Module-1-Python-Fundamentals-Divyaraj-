'''Write a Python program that prints "Hello, World!"'''

print("Hello, World!")
print("Hello, Sanket Sir!")