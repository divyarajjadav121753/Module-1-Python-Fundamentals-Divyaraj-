'''Write a generator function that generates the first 10 even numbers.'''

# Generator function to generate the first 10 even numbers
def even_numbers():
    num = 0
    for _ in range(10):
        yield num
        num += 2

# Example usage
for even in even_numbers():
    print(even)

