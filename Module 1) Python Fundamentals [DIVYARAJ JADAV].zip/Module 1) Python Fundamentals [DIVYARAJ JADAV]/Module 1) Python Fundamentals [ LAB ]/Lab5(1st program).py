'''Write a Python program to print each fruit in a list using a simple for
loop. List1 = ['apple', 'banana', 'mango']'''

# List of fruits
List1 = ['apple', 'banana', 'mango']

# Loop through each fruit in the list and print it
for fruit in List1:
    print(fruit)
