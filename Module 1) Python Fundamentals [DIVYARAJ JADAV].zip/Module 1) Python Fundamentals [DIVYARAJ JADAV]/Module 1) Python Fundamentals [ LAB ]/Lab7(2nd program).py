'''Write a Python program to allocate a string to a variable and print it.'''

# Allocate a string to a variable
message = "Hello, world!"

# Print the string
print(message)
