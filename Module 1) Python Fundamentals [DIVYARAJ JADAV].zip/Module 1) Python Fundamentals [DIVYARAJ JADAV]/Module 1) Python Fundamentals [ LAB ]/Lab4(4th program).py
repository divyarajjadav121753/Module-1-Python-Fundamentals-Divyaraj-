'''Write a Python program to check if a person is eligible to donate blood
using a nested if.'''

# Function to check eligibility to donate blood
def check_eligibility(age, weight):
    if age >= 18:
        if age <= 65:
            if weight >= 50:
                return "Eligible to donate blood."
            else:
                return "Not eligible to donate blood: Weight is less than 50 kg."
        else:
            return "Not eligible to donate blood: Age is more than 65 years."
    else:
        return "Not eligible to donate blood: Age is less than 18 years."

# Example usage
age = int(input("Enter your age: "))
weight = float(input("Enter your weight (in kg): "))

result = check_eligibility(age, weight)
print(result)
