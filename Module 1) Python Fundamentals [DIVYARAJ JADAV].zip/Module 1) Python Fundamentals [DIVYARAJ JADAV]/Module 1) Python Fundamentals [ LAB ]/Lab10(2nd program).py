'''Write a Python program that uses reduce() to find the product of a list of numbers.'''

from functools import reduce

# Function to multiply two numbers
def multiply(x, y):
    return x * y

# Define a list of numbers
numbers = [1, 2, 3, 4, 5]

# Use reduce() to find the product of the list of numbers
product = reduce(multiply, numbers)

# Print the product
print(f"The product of the list of numbers is: {product}")

