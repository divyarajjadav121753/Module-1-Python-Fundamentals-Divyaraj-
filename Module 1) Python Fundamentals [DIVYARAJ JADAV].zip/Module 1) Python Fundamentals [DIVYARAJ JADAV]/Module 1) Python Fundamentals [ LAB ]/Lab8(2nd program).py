'''Write a Python program to stop the loop once 'banana' is found using
the break statement.'''

# List of fruits
List1 = ['apple', 'banana', 'mango']

# Loop through the list and stop the loop once 'banana' is found using the break statement
for fruit in List1:
    if fruit == 'banana':
        break
    print(fruit)
