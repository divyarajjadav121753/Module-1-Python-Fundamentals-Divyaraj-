'''Write a Python program to print "Hello" using a string.'''

# Define the string
greeting = "Hello"

# Print the string
print(greeting)
