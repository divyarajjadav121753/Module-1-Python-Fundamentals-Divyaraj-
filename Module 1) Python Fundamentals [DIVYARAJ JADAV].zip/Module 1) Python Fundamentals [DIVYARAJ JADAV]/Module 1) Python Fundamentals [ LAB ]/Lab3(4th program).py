''' How to take user input using the input() function.'''

# Prompt user for their name
name = input("Enter your name: ")

# Prompt user for their age
age = input("Enter your age: ")

# Print the user input
print(f"Hello, {name}! You are {age} years old.")

#---------------------------------------------------#

# Prompt user for their age
age = input("Enter your age: ")

# Convert age to an integer
age = int(age)

# Print the user's age
print(f"You will be {age + 1} years old next year.")

