'''Write a Python program to apply the map() function to square a list of numbers'''

# Define a list of numbers
numbers = [1, 2, 3, 4, 5]

# Function to square a number
def square(num):
    return num ** 2

# Use the map() function to apply the square function to each number in the list
squared_numbers = list(map(square, numbers))

# Print the squared numbers
print(f"The squared numbers are: {squared_numbers}")
