''': Write a Python program to calculate grades based on percentage using
if-else ladder'''

# Function to determine the grade based on percentage
def calculate_grade(percentage):
    if percentage >= 90:
        return 'A'
    elif percentage >= 80:
        return 'B'
    elif percentage >= 70:
        return 'C'
    elif percentage >= 60:
        return 'D'
    elif percentage >= 50:
        return 'E'
    else:
        return 'F'

# Example usage
percentage = float(input("Enter your percentage: "))

grade = calculate_grade(percentage)
print(f"Your grade is: {grade}")
