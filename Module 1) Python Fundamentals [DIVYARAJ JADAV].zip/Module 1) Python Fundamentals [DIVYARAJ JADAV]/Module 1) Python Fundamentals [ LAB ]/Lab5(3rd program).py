'''Write a Python program to find a specific string in the list using a simple
for loop and if condition.'''

# List of fruits
List1 = ['apple', 'banana', 'mango']

# Function to find a specific string in the list
def find_string(search_string, fruit_list):
    for fruit in fruit_list:
        if fruit == search_string:
            return f"'{search_string}' is found in the list."
    return f"'{search_string}' is not found in the list."

# Example usage
search_string = input("Enter the string to search for: ")

result = find_string(search_string, List1)
print(result)
