'''Write a Python program to find the length of each string in List1.'''

# List of fruits
List1 = ['apple', 'banana', 'mango']

# Loop through each fruit in the list and print its length
for fruit in List1:
    print(f"The length of '{fruit}' is {len(fruit)} characters.")
