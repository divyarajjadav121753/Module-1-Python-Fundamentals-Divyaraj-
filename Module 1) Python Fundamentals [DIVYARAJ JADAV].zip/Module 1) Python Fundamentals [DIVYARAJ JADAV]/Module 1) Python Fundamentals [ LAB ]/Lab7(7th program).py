'''Write a Python program to print the substring between index values 1 and 4.'''

# Define the string
my_string = "Hello, world!"

# Access the substring between index values 1 and 4 using slicing
substring = my_string[1:5]

# Print the substring
print(f"The substring between index values 1 and 4 is: '{substring}'")


