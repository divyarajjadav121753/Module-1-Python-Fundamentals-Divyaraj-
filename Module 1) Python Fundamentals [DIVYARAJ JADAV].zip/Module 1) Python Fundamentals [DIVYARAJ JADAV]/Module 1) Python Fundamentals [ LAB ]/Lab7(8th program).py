'''Write a Python program to print a string from the last character.'''

# Define the string
my_string = "Hello, world!"

# Print the string from the last character using slicing
reversed_string = my_string[::-1]

# Print the reversed string
print(f"The string from the last character is: '{reversed_string}'")
